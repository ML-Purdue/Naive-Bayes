
public class Runner {
    public static void main(String[] args) {
        //Load in the training csv file
        NBClassifier nb = new NBClassifier();
        nb.learn();


        //P.S. this is not a good way to test your model.
        // Make your own test function and calculate the accuracy on both the training set and test set!
        String res = nb.predict("did u get that message");
        assert res.equals("ham");

        res = nb.predict("Fantasy Football is back on your TV");
        assert res.equals("spam");
    }
}
