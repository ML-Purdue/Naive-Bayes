import java.util.HashMap;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class NBClassifier {
    private HashMap<String,Double> spamHM;      //Hashmap containing P(word|spam) for each word that appears in spam messages
    private HashMap<String,Double> hamHM;       //Hashmap containing P(word|ham) for each word that appears in ham messages
    private String csvFileName;                 //The filepath to the csv file
    private int spamCount;                      //The total # of times 'spam' appears in data
    private int hamCount;                       //The total # of times 'spam' appears in data

    public NBClassifier(String filename) {
        spamHM = new HashMap<>();
        hamHM = new HashMap<>();
        csvFileName = filename;
    }

    public void learn(){
        //TODO
        /*Calculate the frequency tables:
        1. Create two hashmaps: one for spam, another for ham(not spam)
        2. Loop through the data; when you encounter a 'spam' example,
                    a.get all the words in the text
                    b. increment each words' counter in the spam hashmap.
        3. Once completed the hashmap, divide all values by the corresponding class count
            to obtain P(word_x|class)

         Do the same for 'ham' examples but with the ham hashmap.*/
        return;
    }
    private int getClassCount(String c) {
        //TODO
        //Get the total # of times a specific class c appears in data
        return 0;
    }

    private double getClassProbability(String c) {
        //TODO
        //Calculate P(Class). P(class) = # of times 'class' is in the data /total # of examples
        return 0.0;
    }

    public String predict(String text) {
        //TODO
        //You can now predict values.
        //  a. Find P(Spam | some_text) and P(Ham | some_text). P(Spam | some_text) ≈ P(Spam)P(word_1|spam)*P(word_2|spam)*...* P(word_n|spam)
        //  b. Predict by choosing the larger value between P(Spam | some_text) and P(Ham | some_text).
        return null;
    }
}
